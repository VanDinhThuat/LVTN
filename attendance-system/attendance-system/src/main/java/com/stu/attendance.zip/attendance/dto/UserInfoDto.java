package com.stu.attendance.dto;

import com.stu.attendance.entity.TaiKhoan;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfoDto {

    private String userId;
    private String fullName;
    private String email;
    private String phone;
    private String className;
    private String classId;
    private TaiKhoan.Role role;
    private String username;
}
